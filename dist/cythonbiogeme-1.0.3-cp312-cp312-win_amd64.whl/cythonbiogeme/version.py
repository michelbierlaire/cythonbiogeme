"""Information about the version of CythonBiogeme

:author: Michel Bierlaire
:date: Fri Sep 15 10:09:50 2023

"""

__version__ = '1.0.3'
