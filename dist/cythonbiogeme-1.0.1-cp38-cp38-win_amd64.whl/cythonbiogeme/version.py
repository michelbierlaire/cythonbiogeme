"""Information about the version of CythonBiogeme

:author: Michel Bierlaire
:date: Mon Apr 17 08:19:34 2023

"""

__version__ = '1.0.1'


